<footer>
    <div class="footer-area footer-bg">
        <div class="container">
            <div class="footer-top">
                <div class="row mb-3">
                        <?php if(isset(\App\Services\GeneralService::getContactDetail()->items)): ?>
                            <?php $__currentLoopData = \App\Services\GeneralService::getContactDetail()->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foooter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-md-4">
                                <div class="footer-widget">
                                    <h4 class="fw-title"><?php echo e($foooter['branch_title']); ?></h4>
                                    <div class="footer-info">
                                        <ul class="list-wrap">
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-pin"></i>
                                                </div>
                                                <div class="content">
                                                    <p><?php echo e($foooter['address']); ?></p>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-phone-call"></i>
                                                </div>
                                                <div class="content">
                                                    <p><?php echo e($foooter['contact_1']); ?></p>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon">
                                                    <i class="fab fa-whatsapp"></i>
                                                </div>
                                                <div class="content">
                                                    <p><?php echo e($foooter['contact_2']); ?></p>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon">
                                                    <i class="flaticon-mail"></i>
                                                </div>
                                                <div class="content">
                                                    <p><?php echo e($foooter['email']); ?></p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="footer-widget">
                                <h4 class="fw-title"><?php echo e(__('general.Kovan_branch')); ?></h4>
                                <div class="footer-info">
                                    <ul class="list-wrap">
                                        <li>
                                            <div class="icon">
                                                <i class="flaticon-pin"></i>
                                            </div>
                                            <div class="content">
                                                <p><?php echo e(__('general.kovan_address')); ?></p>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="icon">
                                                <i class="flaticon-phone-call"></i>
                                            </div>
                                            <div class="content">
                                                <p><?php echo e(__('general.kovan_number')); ?></p>
                                            </div>
                                        </li>
                                        
                                        <li>
                                            <div class="icon">
                                                <i class="flaticon-mail"></i>
                                            </div>
                                            <div class="content">
                                                <p><?php echo e(__('general.kovan_email')); ?></p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    <!--<div class="col-lg-4 col-md-7">
                        <div class="footer-widget">
                            <h4 class="fw-title">Subscribe to Our Newsletter</h4>
                            <div class="footer-newsletter">
                                <p>Sign up to Privitar’s weekly newsletter to get the latest updates.</p>
                                <form action="#">
                                    <input type="email" placeholder="enter your e-mail">
                                    <button type="submit">Subscribe</button>
                                </form>
                                <span>We don’t send you any spam</span>
                            </div>
                        </div>
                    </div>-->
                
                
                    <div class="col-md-4 col-sm-6">
                        <div class="footer-widget">
                            <h4 class="fw-title"><?php echo e(__('general.menu')); ?></h4>
                            <div class="footer-link">
                                <ul class="list-wrap">
                                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('website.home-page')]); ?>">
                                        <a href="<?php echo e(route('website.home-page')); ?>"><?php echo e(__('general.home')); ?></a>
                                    </li>
                                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('website.about-us')]); ?>">
                                        <a href="<?php echo e(route('website.about-us')); ?>"><?php echo e(__('general.about_us')); ?></a>
                                    </li>
                                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('website.services')]); ?>">
                                        <a href="<?php echo e(route('website.services.index')); ?>"><?php echo e(__('general.services')); ?></a>
                                    </li>
                                    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('website.contact-us')]); ?>">
                                        <a href="<?php echo e(route('website.contact-us')); ?>"><?php echo e(__('general.contact_us')); ?></a>
                                    </li>
                                    <li><a href="javascript:void(0)"><?php echo e(__('general.jobs')); ?></a></li>
                                    <li><a href="<?php echo e(route('website.bio-data.index')); ?>"><?php echo e(__('general.bio_data')); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="footer-widget">
                            <h4 class="fw-title">Quick Links</h4>
                            <div class="footer-link">
                                <ul class="list-wrap">
                                    <?php $__currentLoopData = \App\Services\GeneralService::getServicesForFooter(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('website.services.show', $service->id)); ?>"><?php echo e($service->title); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-area bg-white">
        <div class="container">
            <div class="footer-bottom border-0">
                <div class="row align-items-center">
                    <div class="col-md-4">
                        <div class="left-sider">
                            <div class="f-logo">
                                <a href="<?php echo e(route('website.home-page')); ?>"><img src="<?php echo e(asset('assets/website/img/logo/logo.png')); ?>"
                                        alt=""></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="copyright-text">
                            <p>Copyright © Maidcity | All Right Reserved</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="footer-social">
                            <ul class="list-wrap">
                                <li><a href="https://www.facebook.com/maidcity"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li><a href="https://plus.google.com/105420983500050215511"><i
                                            class="fab fa-google-plus"></i></a></li>
                                <li><a href="https://twitter.com/JobuzzC"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="https://www.linkedin.com/in/jobuzz-c-108475150/"><i
                                            class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/layouts/website-components/footer.blade.php ENDPATH**/ ?>