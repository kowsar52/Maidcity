<div id="preloader">
    <div id="loading-center">
        <div class="loader">
            <div class="loader-outter"></div>
            <div class="loader-inner"></div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/layouts/website-components/preloader.blade.php ENDPATH**/ ?>