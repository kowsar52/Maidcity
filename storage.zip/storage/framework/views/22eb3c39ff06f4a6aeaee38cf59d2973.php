 <!-- testimonial-area -->
 <section class="services-area services-bg" data-background="assets/website/img/bg/h2_testimonial_bg.jpg">
     <div class="container">
         <div class="row justify-content-center">
             <div class="col-xl-6 col-lg-8">
                 <div class="section-title white-title text-center mb-50 tg-heading-subheading animation-style2">
                     <h2 class="title tg-element-title text-uppercase"><?php echo e(__('general.what_our_employers_say')); ?></h2>
                 </div>
             </div>
         </div>
         <div class="row services-active">
             <?php if(!empty($employerSay->items)): ?>
                <?php $__currentLoopData = $employerSay->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-lg-4">
                         <div class="services-item">
                             <div class="services-content">
                                 <div class="content-top">
                                     <p class="show-read-more"><?php echo e($emp['review_description']); ?></p>
                                 </div>
                                 <div class="avatar-info mt-2">
                                     <h5 class="mb-0"><?php echo e($emp['employer_name']); ?></h5>
                                     
                                 </div>
                             </div>
                         </div>
                     </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php else: ?>
                 <div class="col-lg-4">
                     <div class="services-item">
                         <div class="services-content">
                             <div class="content-top">
                                 <p class="show-read-more"><?php echo e(__('general.employer_say')); ?></p>
                             </div>
                             <div class="avatar-info mt-2">
                                 <h5 class="mb-0"><?php echo e(__('general.mr_robey_alexa')); ?></h5>
                                 
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col-lg-4">
                     <div class="services-item">
                         <div class="services-content">
                             <div class="content-top">
                                 <p class="show-read-more"><?php echo e(__('general.employer_say2')); ?></p>
                             </div>
                             <div class="avatar-info mt-2">
                                 <h5 class="mb-0"><?php echo e(__('general.cheng')); ?></h5>
                                 
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col-lg-4">
                     <div class="services-item">
                         <div class="services-content">
                             <div class="content-top">
                                 <p class="show-read-more"><?php echo e(__('general.employer_say3')); ?></p>
                             </div>
                             <div class="avatar-info mt-2">
                                 <h5 class="mb-0"><?php echo e(__('general.christine')); ?></h5>
                                 
                             </div>
                         </div>
                     </div>
                 </div>
             <?php endif; ?>
         </div>
     </div>
 </section>
 <!-- testimonial-area-end -->
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/website/home-page/employer-say.blade.php ENDPATH**/ ?>