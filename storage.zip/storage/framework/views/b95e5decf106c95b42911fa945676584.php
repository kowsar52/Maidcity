<div class="dropdown">
    <button class="header-profile" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        <img src="<?php echo e(isset(Auth::user()->photo) ? asset('storage/'.Auth::user()->photo) : asset('assets/images/default-user.png')); ?>" alt="profile">
    </button>
    <ul class="dropdown-menu dropdown-menu-end dropdown-profile shadow">
        <li><a class="dropdown-item" href="<?php echo e(route('website.profile.edit')); ?>"><i class="fas fa-user profile-icon"></i><?php echo e(__('general.profile')); ?></a></li>
        <?php if(auth()->user()->hasRole('Employer')): ?>
            <li><a class="dropdown-item" href="<?php echo e(route('website.bio-data-shortlist.list')); ?>"><i class="fas fa-users profile-icon"></i><?php echo e(__('general.my_favourites')); ?></a></li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('page_Dashboard')): ?>
            <li><a class="dropdown-item" href="<?php echo e(route('filament.admin.pages.dashboard')); ?>" target="_blank"><i class="fas fa-tachometer-alt profile-icon"></i><?php echo e(__('general.dashboard')); ?></a></li>
        <?php endif; ?>
        <li>
            <a class="dropdown-item border-0" href="javascript:void(0)" onclick="document.getElementById('logoutForm').submit()"><i class="fas fa-sign-out-alt profile-icon"></i><?php echo e(__('general.logout')); ?></a>
            <form method="post" action="<?php echo e(route('website.logout')); ?>" class="m-0" id="logoutForm">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </ul>
</div>
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/layouts/website-components/profile-dropdown.blade.php ENDPATH**/ ?>