<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Realtors Club">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->yieldContent('meta-tag'); ?>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/website/img/logo/favicon.png')); ?>">
    <?php echo $__env->yieldContent('css-before'); ?>
    <!-- CSS here -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/odometer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/jarallax.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/aos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/floating-wpp.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/parsley.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/default.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/css/responsive.css')); ?>">
    <?php echo $__env->yieldContent('css-after'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <title><?php echo e($pageTitle ?? ''); ?></title>
</head>
<body>
    <!-- preloader -->
    <?php echo $__env->make('layouts.website-components.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Scroll-top -->
    <button class="scroll-top scroll-to-target" data-target="html">
        <i class="fas fa-angle-up"></i>
    </button>
    <?php echo $__env->make('layouts.website-components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="fix">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- Floating Whatsapp -->
    <div id="floatingWhatsapp"></div>
    <div id="modalContent"></div>
    <div class="modal fade" id="bioDataModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"></div>
    <?php echo $__env->make('layouts.website-components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('assets/website/js/vendor/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/jquery.odometer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/gsap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/ScrollTrigger.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/SplitText.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/gsap-animation.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/jarallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/jquery.parallaxScroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/particles.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/jquery.easypiechart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/jquery.inview.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/ajax-form.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/floating-wpp.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/parsley.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/website/js/main.js')); ?>"></script>
    <?php echo $__env->make('layouts.website-components.facebook-floating-button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.website-components.global-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.website-components.session-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('innerScriptFiles'); ?>
<?php echo $__env->yieldContent('innerScript'); ?>
</body>


<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/layouts/website.blade.php ENDPATH**/ ?>