<?php if($message = \Illuminate\Support\Facades\Session::get('success')): ?>
    <script>
        $(document).ready(function(){
            successMessage("<?php echo e($message); ?>")
        });
    </script>
<?php endif; ?>
<?php if($message = \Illuminate\Support\Facades\Session::get('error')): ?>
    <script>
        $(document).ready(function(){
            errorMessage("<?php echo e($message); ?>")
        });
    </script>
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/layouts/website-components/session-messages.blade.php ENDPATH**/ ?>