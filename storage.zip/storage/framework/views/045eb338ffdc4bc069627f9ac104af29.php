  <!-- aps-area -->
  <section class="about-area-three">
      <div class="container">
          <div class="row align-items-center justify-content-center">
              <div class="col-lg-6 col-md-9">
                  <div class="about-img-wrap-three">
                      <img src="<?php echo e(isset($apsImage1->items) ? asset('storage/'.$apsImage1->items) : asset('assets/website/img/images/aps.png')); ?>" alt=""
                          data-aos="fade-down-right" data-aos-delay="0" width="405px" height="297px">
                      <img src="<?php echo e(isset($apsImage2->items) ? asset('storage/'.$apsImage2->items) : asset('assets/website/img/images/h2_about_img02.jpg')); ?>" alt=""
                          data-aos="fade-left" data-aos-delay="400" width="247px" height="247px">
                      <div class="experience-wrap" data-aos="fade-up" data-aos-delay="300">
                      </div>
                  </div>
              </div>
              <div class="col-lg-6">
                  <div class="about-content-three">
                      <div class="section-title-two mb-20 tg-heading-subheading animation-style3">
                          
                          <h2 class="title tg-element-title"><?php echo e(__('general.advance_placement_scheme_aps')); ?></h2>
                      </div>
                      <p class="info-one"><?php echo e(isset($apsDescription->items) ? $apsDescription->items : __('general.aps_intro')); ?></p>
                      <div class="about-list-two">
                          <ul class="list-wrap">
                              <?php if(isset($apsList->items) && !empty($apsList->items)): ?>
                                  <?php $__currentLoopData = $apsList->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <li><i class="fas fa-arrow-right"></i><?php echo e($l); ?></li>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                  <li><i class="fas fa-arrow-right"></i><?php echo e(__('general.face_to_face_interview')); ?></li>
                                  <li><i class="fas fa-arrow-right"></i><?php echo e(__('general.better_matching')); ?></li>
                                  <li><i class="fas fa-arrow-right"></i><?php echo e(__('general.fast_deploment_3_days')); ?></li>
                                  <li><i class="fas fa-arrow-right"></i><?php echo e(__('general.by_ministry_of_Manpower_mom')); ?></li>
                              <?php endif; ?>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <div class="about-shape-wrap-two">
          <img src="<?php echo e(asset('assets/website/img/images/h2_about_shape01.png')); ?>" alt="">
          <img src="<?php echo e(asset('assets/website/img/images/h2_about_shape02.png')); ?>" alt="">
          <img src="<?php echo e(asset('assets/website/img/images/h2_about_shape03.png')); ?>" alt="" data-aos="fade-left"
              data-aos-delay="500">
      </div>



  </section>
  <!-- aps-area-end -->
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/website/home-page/aps.blade.php ENDPATH**/ ?>