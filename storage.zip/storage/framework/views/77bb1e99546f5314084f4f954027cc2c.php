<?php
    $recommended_mdws = \App\Services\FdwBioDataService::getRecommendedMdws();
?>
<!-- project-area -->
<section class="pt-80 pb-30">
    <div class="container custom-container">
        <div class="row justify-content-center">
            <?php if(isset($heading) && count($recommended_mdws) > 0): ?>
                <div class="bg-custom-primary p-3 mb-3">
                    <h3 class="text-white mb-0"><?php echo e(__('general.recommended_mdw')); ?></h3>
                </div>
            <?php endif; ?>
            <?php $__currentLoopData = $recommended_mdws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2 col-md-3">
                    <div class="blog-post-item-two">
                        <div class="blog-post-thumb-two">
                            <a href="<?php echo e(route('website.bio-data.show',$d->id)); ?>">
                                <img src="<?php echo e(\App\Services\GeneralService::getBioDataImage($d->photo)); ?>" alt="">
                            </a>
                            <ul class="nationality-list m-0 <?php if(auth()->guard()->guest()): ?> filter <?php endif; ?>">
                                <?php $__currentLoopData = $d->bio_data_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="javascript:void(0)" onclick="DataTypeModal(<?php echo e($d->id); ?>);">
                                            <?php echo e(isset($bio) ? \App\Services\GeneralService::bioDataTypeForDropdown($bio) : 'N/A'); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="flag_div <?php if(auth()->guard()->guest()): ?> filter <?php endif; ?>">
                                <img
                                    src="<?php echo e(isset($d->nationality) ? \App\Services\GeneralService::getCountryImage($d->nationality) : asset('assets/website/img/flag/other.png')); ?>"
                                    alt="" class="flag">
                            </div>
                        </div>
                        <div class="blog-post-content-two <?php if(auth()->guard()->guest()): ?> filter <?php endif; ?>">
                            <div>
                                <?php $__currentLoopData = $d->overseasEmploymentHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($record->country_id)): ?>
                                        <span class="bg-warning p-1 fs-8 text-dark rounded-2"><?php echo e('EX-'.\App\Services\GeneralService::getCountries($record->country_id)); ?></span>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="mt-2">
                                <?php $__currentLoopData = $d->languageAbilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($language->language_id)): ?>
                                        <span class="bg-primary p-1 fs-8 text-white rounded-2"><?php echo e(\App\Services\GeneralService::languageForDropdown($language->language_id) ?? 'N/A'); ?></span>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="mt-2 d-flex flex-wrap gap-1">
                                <?php if(isset($d->bioDataDetail->recommended_helper)): ?>
                                    <?php $__currentLoopData = $d->bioDataDetail->recommended_helper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="bg-danger p-1 fs-8 text-white rounded-2"><?php echo e(\App\Services\GeneralService::categoryForDropdown($data)); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- project-area-end -->
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/website/bio-data/maids.blade.php ENDPATH**/ ?>