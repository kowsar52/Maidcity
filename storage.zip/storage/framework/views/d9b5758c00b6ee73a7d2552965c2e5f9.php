<section class="breadcrumb-area breadcrumb-bg p-0">
    <div class="">
        <div id="carouselExampleCaptions" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php if(!empty($sliderImg->items)): ?>
                <?php $__currentLoopData = $sliderImg->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php if($loop->iteration == 1): ?> active <?php endif; ?>">
                        <img src="<?php echo e(asset('storage/'.$images)); ?>"
                             alt="" data-aos="fade-left" data-aos-delay="400" class="mb-2 w-100 slider_img_h">
                        <div class="overlay"></div>
                        <div class="carousel-caption d-none d-md-block">
                            <h5 class="fs-1 text-white text-stroke"><?php echo e($slider->items ??  __('general.welcome_to_maidcity')); ?></h5>
                            <p class="fs-4 fw-bold text-white text-stroke"><?php echo e($licenseNo->items ?? __('general.license_no_97C4834')); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="carousel-item active position-relative">
                        <img src="<?php echo e(asset('assets/website/test-slider.jpg')); ?>"
                             alt="" data-aos="fade-left" data-aos-delay="400" class="mb-2 w-100 slider_img_h">
                        <div class="overlay"></div>
                        <div class="carousel-caption d-none d-md-block">
                            <h5 class="fs-1 text-white text-stroke"><?php echo e($slider->items ??  __('general.welcome_to_maidcity')); ?></h5>
                            <p class="fs-4 fw-bold text-white text-stroke"><?php echo e(__('general.license_no_97C4834')); ?></p>
                        </div>
                    </div>
                    <div class="carousel-item active position-relative">
                        <img src="<?php echo e(asset('assets/website/main-banner-slider-D2.png')); ?>"
                             alt="" data-aos="fade-left" data-aos-delay="400" class="mb-2 w-100 slider_img_h">
                        <div class="overlay"></div>
                        <div class="carousel-caption d-none d-md-block">
                            <h5 class="fs-1 text-white text-stroke"><?php echo e($slider->items ??  __('general.welcome_to_maidcity')); ?></h5>
                            <p class="fs-4 fw-bold text-white text-stroke"><?php echo e(__('general.license_no_97C4834')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>






































</section>
<?php /**PATH /Applications/MAMP/htdocs/Maidcity/resources/views/website/home-page/banner.blade.php ENDPATH**/ ?>